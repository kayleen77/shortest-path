# shortest-path
This library uses dijkstra's algorithm to find the shortest path from a given source vertex to all vertices.